package view;

/**
 * Interface used for handling animation
 * @author 
 *
 */
public interface Animated {
	public void handleAnimation();
}
